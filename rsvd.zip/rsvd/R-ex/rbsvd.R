### Name: rbsvd
### Title: Robust singular value decomposition
### Aliases: rbsvd
### Keywords: Statistics

### ** Examples

n<-100
m<-20
y<-matrix(rnorm(n*m),n,m)
y[2,2]<-y[2,2]+1000
y[20,15]<-y[20,15]+10000
rbsvd(y)



