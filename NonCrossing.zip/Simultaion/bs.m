function [basis, deriv] = bs(order, knots, x)

% INPUT
% order: the order of basis splines (2 for linear, 
%              3 for quadratic  and 4 for cubic, etc.) 
% knots: the location of unique knots
% x(optinal): the design vector where the basis function
%                 is to be evaluated.

% OUTPUT
% B: the first derivative of the basis functions
%     with {numel(knots) + order - 2} columns

% Copyright 2013 LIPING ZHU


knots = unique(knots);                                         % remove redudant knots
p = order - 1;                                                       % the derivative is an (order-1)-th bspline functions
bspline_basis = bspline_basismatrix(p, knots, x);   % calculating the (order-1)-th bspline functions
knots = [ones(p,1)*knots(1); ...
    knots(:); ones(p,1)*knots(end)];                         % expand the knots locations
[~, dctrl] = bspline_deriv(order, ...
    knots, eye(length(knots)-order));                      % calculating the controlling constant matrix 
deriv = bspline_basis*dctrl';                                 % calculating the derivative function
basis = bspline_basismatrix(order, knots, x);         % calculating the (order)-th bspline functions

%basis(:,find(sum(basis.^2)==0)) = [];
%deriv(:,find(sum(deriv.^2)==0)) = [];


function [dknots, dctrl] = bspline_deriv(order, knots, ctrl)
p = order - 1;
tmp = size(ctrl);
n = tmp(2)-1;
dim = tmp(1);

% derivative knots
dknots = knots(2:max(size(knots))-1);

% derivative control points
dctrl = zeros(dim,n);
for i = 1 : n
    dctrl(:,i) = (p / (knots(i+p+1) - knots(i+1))) * (ctrl(:,i+1) - ctrl(:,i));
end


function B = bspline_basismatrix(order, knots,x)

% INPUT
% order: the order of basis splines (2 for linear, 
%              3 for quadratic  and 4 for cubic, etc.) 
% knots: the location of unique knots
% x(optinal): the design vector where the basis function
%                 is to be evaluated.

% OUTPUT
% B: the basis matrix with numel(knots) + order - 2 columns

% Copyright 2013 LIPING ZHU

n = order; 
knots = unique(knots);
t = [ones(n-1,1)*knots(1); knots(:); ...
    ones(n-1,1)*knots(end)];

if nargin > 2
    B = zeros(numel(x),numel(t)-n);
    for j = 0 : numel(t)-n-1
        B(:,j+1) = bspline_basis(j,n,t,x);
    end
else
    [b,x] = bspline_basis(0,n,t);
    B = zeros(numel(x),numel(t)-n);
    B(:,1) = b;
    for j = 1 : numel(t)-n-1
        B(:,j+1) = bspline_basis(j,n,t,x);
    end
end





function [y,x] = bspline_basis(j,n,t,x)


validateattributes(j, {'numeric'}, {'nonnegative','integer','scalar'});
validateattributes(n, {'numeric'}, {'positive','integer','scalar'});
validateattributes(t, {'numeric'}, {'real','vector'});
assert(all( t(2:end)-t(1:end-1) >= 0 ), ...
    'Knot vector values should be nondecreasing.');
if nargin < 4
    x = linspace(t(n), t(end-n+1), 100);  % allocate points uniformly
else
    validateattributes(x, {'numeric'}, {'real','vector'});
end
assert(0 <= j && j < numel(t)-n, ...
    'Invalid interval index j = %d, expected 0 =< j < %d (0 =< j < numel(t)-n).', j, numel(t)-n);

y = bspline_basis_recurrence(j,n,t,x);

function y = bspline_basis_recurrence(j,n,t,x)

y = zeros(size(x));
if n > 1
    b = bspline_basis(j,n-1,t,x);
    dn = x - t(j+1);
    dd = t(j+n) - t(j+1);
    if dd ~= 0  % indeterminate forms 0/0 are deemed to be zero
        y = y + b.*(dn./dd);
    end
    b = bspline_basis(j+1,n-1,t,x);
    dn = t(j+n+1) - x;
    dd = t(j+n+1) - t(j+1+1);
    if dd ~= 0
        y = y + b.*(dn./dd);
    end
elseif t(j+2) < t(end)  % treat last element of knot vector as a special case
	y(t(j+1) <= x & x < t(j+2)) = 1;
else
	y(t(j+1) <= x) = 1;
end
