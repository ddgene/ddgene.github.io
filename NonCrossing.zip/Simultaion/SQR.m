function [theta, EXITFLAG] = SQR(x, y, tau, beta, knots_x, knots_tau, order_x, order_tau)
% Approximation of different quantile curves or sufaces by tensor product
%   b-spline method. Noncorssing constraints has been added. Traditional
%   linear programming solution for quantile regression is obtained through
%   determining the shadow prices of the dual problem.
%   
%
% Parameters:
% -----------
% x:  N x p matrix
%     predictors
% y:  N x 1 vector
%     reponses
% tau: kn x 1 vector
%     quantile levels
% beta: p x q matrix
%     coefficients matrix (central dimension reduction subspace)
% knots_x: j1 x q matrix
%     knots sequences for XB
% knots_tau: j2 x 1 vector
%     knots sequence for tau
% order_x: integer
%     b-spline orders for XB
% order_tau: integer
%     b-spline order for tau
%
% Retrun:
% -------
% theta: (j1^q * j2) x 1 vector
%     control points of tensor product b-spline
%

xb = x * beta;                                                             % obtain the covariates
[n, dim] = size(xb);                                                       % determine the number of indexes
m = length(tau);                                                           

nknots_x = length(knots_x);
nknots_tau = length(knots_tau);
ncol_x = nknots_x + order_x - 2;                                           % determine the col number of b-spline bases
ncol_tau = nknots_tau + order_tau - 2;

if(dim == 1)                                                               % get tensor product spline design matrix 
    [bas1, ~] = bs(order_x, knots_x, xb);
    [des_tau, ~] = bs(order_tau, knots_tau, tau);
    T = kron(bas1, des_tau);
else
    [bas1, ~] = bs(order_x, knots_x(:, 1), xb(:, 1));
    [bas2, ~] = bs(order_x, knots_x(:, 2), xb(:, 2));
    T = zeros(n, ncol_x ^ dim);                                            % tensor design matrix for x
    for i = 1 : n
        T(i, :) = kron(bas1(i, :), bas2(i, :));
    end
    [des_tau, ~] = bs(order_tau, knots_tau, tau);                          
    T = kron(T, des_tau);
end


b = zeros([(ncol_x ^ dim) * ncol_tau, 1]);                                 % equality constraints

tau0 = repmat(tau, [n, 1]);                                                % up and low bounds
lb = tau0 - 1;

yy = repmat(y, [1, m]);                                                    % expand original reponses to match predictors
yy = reshape(yy', [n * m, 1]);

[~, ~, EXITFLAG, ~, lambda] = linprog(-yy, [], [], T', b, lb, tau0);       % solve dual problem for shadow price
theta = lambda.eqlin;

end