tic
s1 = RandStream.create('mrg32k3a','Seed', 12345);
s0 = RandStream.setGlobalStream(s1);

% Model setting
n = 400;                                                                   % sample size
p = 20;                                                                    % sample vector dimesion
q = 1;                                                                     % number of index in multi-index model
kn = 20;                                                                   % number of quantiles levels
model = 1;                                                                 % simulation generating model
error = 1;
nknots_x = 8;
nknots_tau = 8;
order_x = 4;
order_tau = 4;


% Generating sample points and quantile levels
muu = zeros(p, 1);                                                        
sigg = eye(p);
x = mvnrnd(muu, sigg, n);

beta0 = [1; -ones(7, 1); ones(7, 1); zeros(p - 15, 1)];                                                
xb0 = x * beta0;

tau_up = 0.99;                                                             % specify quantile levels
tau_low = 0.01;
tau = linspace(tau_low, tau_up, kn)';


% Generating prediction points and quantile levels
while(1)
    n_x = 100;                                                             % number of prediction points                                              
    x0 = zeros(n_x, p);
    for i = 1 : n_x
        while(1)
            x0(i, :) = mvnrnd(muu, sigg, 1);
            if(max(x0(i, :)) <= min(max(x)) && min(x0(i, :)) >= max(min(x)))
                break;
            end
        end
    end
    x0b0 = x0 * beta0;
    if(max(xb0) > max(x0b0) && min(xb0) < min(x0b0))
        break;
    end
end

tau_pred = [0.025, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.975]';         % specify prediction quantile levels
n_tau = length(tau_pred);

% Monte Carlo Simulation
MCnum = 500;                                                                % simulation times

B = zeros(p, MCnum);
ydata = zeros(n, MCnum);
MSEprop = zeros(n_tau, MCnum);                                             % summarization Table
MSEcr = zeros(n_tau, MCnum);
MSEcomp = zeros(n_tau, MCnum);
MSEcompCher = zeros(n_tau, MCnum);
MSEora = zeros(n_tau, MCnum);
MSEcomp_ora = zeros(n_tau, MCnum);
MSEcompCher_ora = zeros(n_tau, MCnum);

h = waitbar(0, 'Please wait...');
for ii = 1 : MCnum
    while(1)
        switch model                                                       % data generation scenarios
            case 1
                mu = cos(xb0./ 2) + exp(-abs(xb0)./ 2);
                mu0 = cos(x0b0./ 2) + exp(-abs(x0b0)./ 2);
                switch error
                    case 1
                        y = mu + randn(n, 1);
                        y_true = ones(n_tau, 1) * mu0' + norminv(tau_pred, 0, 1) * ones(1, n_x);
                    case 2
                        y = mu + trnd(3, [n, 1]) * sqrt(1/3);
                        y_true = ones(n_tau, 1) * mu0' + tinv(tau_pred, 3) * ones(1, n_x) * sqrt(1/3);
                    case 3
                        y = mu + exprnd(1, n, 1);
                        y_true = ones(n_tau, 1) * mu0' + expinv(tau_pred, 1) * ones(1, n_x);
                end
            case 2
                mu = exp(-abs(xb0));
                mu0 = exp(-abs(x0b0));
                switch error
                    case 1
                        eps = randn(n, 1);
                        y = mu + sqrt(mu).* eps;
                        y_true = ones(n_tau, 1) * mu0' + norminv(tau_pred) * sqrt(mu0)';
                    case 2
                        eps = trnd(3, [n, 1]) * sqrt(1/3);
                        y = mu + sqrt(mu).* eps;
                        y_true = ones(n_tau, 1) * mu0' + tinv(tau_pred, 3) * sqrt(mu0)' * sqrt(1/3);
                    case 3
                        eps = exprnd(1, [n, 1]);
                        y = mu + sqrt(mu).* eps;
                        y_true = ones(n_tau, 1) * mu0' + expinv(tau_pred, 1) * sqrt(mu0)';
                end
        end
        beta = dMAVE(x, y, q);                                             % dimension reduction for index vector
        beta = beta / beta(1);                                             % parametrization
        xb = x * beta;
        x0b = x0 * beta;
        if(max(xb) > max(x0b) && min(xb) < min(x0b))
            break;
        end
    end
    B(:, ii) = beta;
    ydata(:, ii) = y;
    
    % Proposed method
    s = linspace(0, 1, nknots_x);                                          % sepcify knots sequence
    knots_x = quantile(xb, s);
    s = linspace(0, 1, nknots_tau);
    knots_tau = quantile(tau, s);
    
    lambda_my = NonCross(x, y, tau, beta, knots_x, knots_tau, order_x, order_tau);
    z_my = PredNonCross(x0b, tau_pred, lambda_my, knots_x, knots_tau, order_x, order_tau);
    
    % Non-constraint QR
    lambda_cr = SQR(x, y, tau, beta, knots_x, knots_tau, order_x, order_tau);
    z_cr = PredNonCross(x0b, tau_pred, lambda_cr, knots_x, knots_tau, order_x, order_tau);
    
    % Oracle model with true B
    s = linspace(0, 1, nknots_x);                                          % sepcify knots sequence(for oracle results)
    knots_x0 = quantile(xb0, s);
    lambda_ora = NonCross(x, y, tau, beta0, knots_x0, knots_tau, order_x, order_tau);
    z_ora = PredNonCross(x0b0, tau_pred, lambda_ora, knots_x0, knots_tau, order_x, order_tau);
                                                                           
    MSEprop(:, ii) = sum((z_my - y_true).^ 2, 2)./ n_x;
    MSEcr(:, ii) = sum((z_cr - y_true).^ 2, 2)./ n_x;
    MSEora(:, ii) = sum((z_ora - y_true).^ 2, 2)./ n_x;
    
    % Non-crossing Dette(2008)
    kern_r = 'Gaussian';                                                   % specify kernels
    kern_d = 'Epanechnikov';
    
    trandata = [xb, y];                                                    % get hr_opt
    fid = fopen('xy.csv', 'w');
    fprintf(fid, '%g, %g\r\n', trandata');
    fclose(fid);
    system('R CMD BATCH bandW.R');
    fileID = fopen('h.txt','r');
    formatSpec = '%f';
    hr = fscanf(fileID, formatSpec);
    fclose(fileID);
    
    const = (tau_pred.* (1 - tau_pred)./ (normpdf(norminv(tau_pred)).^ 2)).^ (1/5);
    hr = hr * const;
    hd = min([tau_pred, 1 - tau_pred, hr.^ 1.3], [], 2);
    
    z_comp = ncnp(xb, y, x0b, tau_pred, kern_r, hr, kern_d, hd, 500);      % training and prediction
    
    MSEcomp(:, ii) = sum((z_comp - y_true).^ 2, 2)./ n_x;
    clear hr hd
    
	%Non-crossing method of Chernozhukov, Fernandez-Val and Galichon (2010)
    z_comp_cher = CherNonCro(x, y, x0, tau_pred, beta, 200, 200, knots_x, knots_tau, order_x, order_tau);
    MSEcompCher(:, ii) = sum((z_comp_cher - y_true).^ 2, 2)./ n_x;
    
    trandata = [xb0, y];                                                   % oracle results
    fid = fopen('xy.csv', 'w');
    fprintf(fid, '%g, %g\r\n', trandata');
    fclose(fid);
    system('R CMD BATCH bandW.R');
    fileID = fopen('h.txt','r');
    formatSpec = '%f';
    hr = fscanf(fileID, formatSpec);
    fclose(fileID);
    
    const = (tau_pred.* (1 - tau_pred)./ (normpdf(norminv(tau_pred)).^ 2)).^ (1/5);
    hr = hr * const;
    hd = min([tau_pred, 1 - tau_pred, hr.^ 1.3], [], 2);
    
    z_comp_ora = ncnp(xb0, y, x0b0, tau_pred, kern_r, hr, kern_d, hd, 500);
    
    MSEcomp_ora(:, ii) = sum((z_comp_ora - y_true).^ 2, 2)./ n_x;
    
    z_comp_cher_ora = CherNonCro(x, y, x0, tau_pred, beta0, 200, 200, knots_x0, knots_tau, order_x, order_tau);
    MSEcompCher_ora(:, ii) = sum((z_comp_cher_ora - y_true).^ 2, 2)./ n_x;
    
    perc = round(ii * 100 / MCnum);
    waitbar(perc / 100, h, sprintf('Simulation progress: %d%% done.', perc))
end
close(h) 
toc

% Restore random stream
RandStream.setGlobalStream(s0);

Filename = strcat(strcat(strcat('SingleM', num2str(model)), num2str(error)),'.mat');
save(Filename);