function CondCDF = CondDistFuncEst(x, y, x0, y0, h, kern)
% Function CondDistFuncEst is to estimate the conditional distribution
% function of Y given X
% Define F(Y0 | X0) = Prob(Y < Y0 | X = X0). 
% Evaluate the conditional distribution function at X0 and Y0.

% INPUT: 
% X: Predictor Obs for training
% Y: Response Obs for training
% Both X and Y must be of the same length, say, n x 1;
% X0: Evaluate the conditional distribution at the test covariate set X0;
% X0 is of size sizex x 1
% Y0: Evaluate the conditional distribution at the test covariate set Y0;
% Y0 is of size sizey x sizex
% kern is the kernal to be used. Options: "Gaussian","Quartic","Epanechnikov"

% OUTPUT:
% CondCDF: an sizey x sizex matrix
% Each Column is an increasing function

n = length(y);
sizey = size(y0, 1);
sizex = length(x0);
CondCDF = zeros(sizey, sizex);

ux = (x * ones(1, sizex) - ones(n, 1) * x0') / h;
if(strcmp(kern, 'Gaussian'))
    wgt = normpdf(ux);                                                     % Gaussian
else
    if(strcmp(kern, 'Quartic'))
       wgt = 15/16 * (1 - ux.^ 2).^ 2.* (abs(ux) <= 1);                    % Quartic (Bivariate)
    else
       wgt = 3/4 * (1 - ux.^ 2).* (abs(ux) <= 1);                          % Epanechnikov
    end
end
wgt = wgt./ (ones(n, 1) * sum(wgt));

for kk = 1 : sizex
    uy = (y * ones(1, sizey) <= ones(n, 1) * y0(:, kk)');
    CondCDF(:, kk) = uy' * wgt(:, kk);
end
end
