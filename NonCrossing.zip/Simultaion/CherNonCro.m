function  quantiles = CherNonCro(x, y, x0, tau_pred, beta, N, M, knots_x, knots_tau, order_x, order_tau)

x0b = x0 * beta;

sizex = length(x0b);
sizet = length(tau_pred);
quantiles = zeros(sizet, sizex);

if(M > N)
    N = M;
end

z = linspace(0.01, 0.99, N)';                                              % N for curve fitting;
z0 = linspace(0.025, 0.975, M)';                                           % M for integrating to cdf F and reversing to quantile function Q;

BetaTau = SQR(x, y, z, beta, knots_x, knots_tau, order_x, order_tau);

y0 = PredNonCross(x0b, z0([1, M]), BetaTau, knots_x, knots_tau, order_x, order_tau);
y0min = y0(1, :);
y0max = y0(2, :);

for ii = 1 : sizex
    Qtau = PredNonCross(x0b(ii), z0, BetaTau, knots_x, knots_tau, order_x, order_tau);
    y0 = linspace(y0min(ii), y0max(ii), M)';                               % note that y0 is increasing here;
    Fhat = zeros(M, 1);
    for jj = 1 : M
        Fhat(jj) = mean(Qtau <= y0(jj));                                   % Fhat is also increasing;
    end
    
    if(min(Fhat) > min(tau_pred))
        Fhat = [min(tau_pred); Fhat];
        y0 = [min(y0) - 1E-4; y0];
    end
    
    if(max(Fhat) < max(tau_pred))
        Fhat = [Fhat; max(tau_pred)];
        y0 = [y0; max(y0) + 1E-4];
    end
    
    [Fhat, I] = unique(Fhat);                                              % remove the redundant y0s leaving the inferior y0;
    y0 = y0(I);
    
    quantiles(:, ii) = interp1(Fhat, y0, tau_pred);
end
end
