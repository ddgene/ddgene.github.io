dat = xlsread('04cars.xls');                                               % read data
data = dat;

q = 1;                                                                     % single index / multiple index
[rows, ~] = find(isnan(data));                                             % find nan
data(rows, :) = [];
[rows, ~] = find(data(:, 5) == 1);                                         % find pickup trucks
data(rows, :) = [];
y = data(:, 8);
y = (y - mean(y)) / std(y);

x = data;
x(:, [5, 8, 9]) = [];                                                      % useful data extraction
n = size(x, 1);
xx = x(:, 7 : 15);
xx = (xx - ones(n, 1) * mean(xx))./ (ones(n, 1) * std(xx));
x = [xx, x(:, 1 : 6)];
clear xx dat

nknots_x = 8;                                                              % tensor product spline setting
nknots_tau = 8;
order_x = 4;
order_tau = 4;
kn = 20;       
tau_up = 0.99;                                                             % specify quantile levels
tau_low = 0.01;
tau = linspace(tau_low, tau_up, kn)';

tau_pred = [0.025, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.975]';         % specify prediction quantile levels
n_tau = length(tau_pred);

beta0 = dMAVE(x, y, 1);                                                    % dimension reduction for single-index vector
%beta = CUME(x, y, 'cont', q);
beta = beta / beta(1);
xb = x * beta;

% Using dMAVE's results to compare different methods
s = linspace(0, 1, nknots_x);                                              % sepcify knots sequence
knots_x = quantile(xb, s);
s = linspace(0, 1, nknots_tau);
knots_tau = quantile(tau, s);

n0 = 50;
s = linspace(0.01, 0.99, n0);
x0 = quantile(x, s);
x0b = x0 * beta;

lambda_my = NonCross(x, y, tau, beta, knots_x, knots_tau, order_x, order_tau);% estimate the control points
z_my = PredNonCross(x0b, tau_pred, lambda_my, knots_x, knots_tau, order_x, order_tau);

lambda_cr = SQR(x, y, tau, beta, knots_x, knots_tau, order_x, order_tau);
z_cr = PredNonCross(x0b, tau_pred, lambda_cr, knots_x, knots_tau, order_x, order_tau);

kern_r = 'Gaussian';
kern_d = 'Epanechnikov';

trandata = [xb, y];
fid = fopen('xy.csv', 'w');
fprintf(fid, '%g, %g\r\n', trandata');
fclose(fid);
system('R CMD BATCH bandW.R');
fileID = fopen('h.txt','r');
formatSpec = '%f';
hr = fscanf(fileID, formatSpec);
fclose(fileID);

const = (tau_pred.* (1 - tau_pred)./ (normpdf(norminv(tau_pred)).^ 2)).^ (1/5);
hr = hr * const;
hd = min([tau_pred, 1 - tau_pred, hr.^ 1.3], [], 2);
z_comp = ncnp(xb, y, x0b, tau_pred, kern_r, hr, kern_d, hd, 500);

    
    
%% Non-crossing Plot
% Colorful Pics

set(gcf, 'PaperUnits', 'centimeters')
set(gcf, 'Position', [100 100 600 500])
% Non-constraint
z = [x0b(:)'; z_my];
z = sortrows(z', 1)';
z = z(2 : (n_tau + 1), :);
plot(sort(x0b)', z(1, :), '-.', 'color', [16, 142, 255] / 255)
hold on
plot(sort(x0b)', z(2, :), '--', 'color', [206, 0, 0] / 255)
hold on
plot(sort(x0b)', z(3, :), '-.', 'color', [255, 204, 0] / 255)
hold on
plot(sort(x0b)', z(4, :), '--', 'color', [173, 100, 173] / 255)
hold on
plot(sort(x0b)', z(5, :), '-', 'color', [124, 181, 42] / 255)
hold on
plot(sort(x0b)', z(6, :), '--', 'color', [173, 100, 173] / 255)
hold on
plot(sort(x0b)', z(7, :), '-.', 'color', [255, 204, 0] / 255)
hold on
plot(sort(x0b)', z(8, :), '--', 'color', [206, 0, 0] / 255)
hold on
plot(sort(x0b)', z(9, :), '-.', 'color', [16, 142, 255] / 255)
hold off
xlabel('x^T\beta')
ylabel('y')
title('Different Conditional Quantile Curves (Proposed Method)')
legend('\tau=0.025', '\tau=0.05', '\tau=0.1', '\tau=0.25', '\tau=0.5', ...
    '\tau=0.75', '\tau=0.9', '\tau=0.95', '\tau=0.975', 'Location', 'SouthWest')

%print '-dpdf' 'RealNC2'

set(gcf, 'PaperUnits', 'centimeters')
set(gcf, 'Position', [100 100 600 500])
% Non-constraint
z = [x0b(:)'; z_cr];
z = sortrows(z', 1)';
z = z(2 : (n_tau + 1), :);
plot(sort(x0b)', z(1, :), '-.', 'color', [16, 142, 255] / 255)
hold on
plot(sort(x0b)', z(2, :), '--', 'color', [206, 0, 0] / 255)
hold on
plot(sort(x0b)', z(3, :), '-.', 'color', [255, 204, 0] / 255)
hold on
plot(sort(x0b)', z(4, :), '--', 'color', [173, 100, 173] / 255)
hold on
plot(sort(x0b)', z(5, :), '-', 'color', [124, 181, 42] / 255)
hold on
plot(sort(x0b)', z(6, :), '--', 'color', [173, 100, 173] / 255)
hold on
plot(sort(x0b)', z(7, :), '-.', 'color', [255, 204, 0] / 255)
hold on
plot(sort(x0b)', z(8, :), '--', 'color', [206, 0, 0] / 255)
hold on
plot(sort(x0b)', z(9, :), '-.', 'color', [16, 142, 255] / 255)
hold off
xlabel('x^T\beta')
ylabel('y')
title('Different Conditional Quantile Curves (Non-constraint QR)')
legend('\tau=0.025', '\tau=0.05', '\tau=0.1', '\tau=0.25', '\tau=0.5', ...
    '\tau=0.75', '\tau=0.9', '\tau=0.95', '\tau=0.975', 'Location', 'SouthWest')

%print '-dpdf' 'RealWC2'

set(gcf, 'PaperUnits', 'centimeters')
set(gcf, 'Position', [100 100 600 500])
% Non-constraint
z = [x0b(:)'; z_comp];
z = sortrows(z', 1)';
z = z(2 : (n_tau + 1), :);
plot(sort(x0b)', z(1, :), '-.', 'color', [16, 142, 255] / 255)
hold on
plot(sort(x0b)', z(2, :), '--', 'color', [206, 0, 0] / 255)
hold on
plot(sort(x0b)', z(3, :), '-.', 'color', [255, 204, 0] / 255)
hold on
plot(sort(x0b)', z(4, :), '--', 'color', [173, 100, 173] / 255)
hold on
plot(sort(x0b)', z(5, :), '-', 'color', [124, 181, 42] / 255)
hold on
plot(sort(x0b)', z(6, :), '--', 'color', [173, 100, 173] / 255)
hold on
plot(sort(x0b)', z(7, :), '-.', 'color', [255, 204, 0] / 255)
hold on
plot(sort(x0b)', z(8, :), '--', 'color', [206, 0, 0] / 255)
hold on
plot(sort(x0b)', z(9, :), '-.', 'color', [16, 142, 255] / 255)
%hold on
%tmp = repmat(x0b', 9, 1);
%scatter(tmp(:), z_comp(:));
hold off
xlabel('x^T\beta')
ylabel('y')
title('Different Conditional Quantile Curves (Dette Method)')
legend('\tau=0.025', '\tau=0.05', '\tau=0.1', '\tau=0.25', '\tau=0.5', ...
    '\tau=0.75', '\tau=0.9', '\tau=0.95', '\tau=0.975', 'Location', 'SouthWest')

%% Black & White
%{
% QuantileFunction
% Proposed 
z = [x0b(:)'; z_my];
z = sortrows(z', 1)';
z = z(2 : (n_tau + 1), :);
plot(sort(x0b)', z(1, :), 'k+-')
hold on
plot(sort(x0b)', z(2, :), 'kx--')
hold on
plot(sort(x0b)', z(3, :), 'k^-.')
hold on
plot(sort(x0b)', z(4, :), 'ks-')
hold on
plot(sort(x0b)', z(5, :), 'ko--')
hold on
plot(sort(x0b)', z(6, :), 'kd-.')
hold on
plot(sort(x0b)', z(7, :), 'k*-')
hold on
plot(sort(x0b)', z(8, :), 'kd--')
hold on
plot(sort(x0b)', z(9, :), 'k^-.')
hold off
xlabel('x^T\beta')
ylabel('y')
title('Different Conditional Quantile Curves (Proposed Method)')
legend('\tau=0.025', '\tau=0.05', '\tau=0.1', '\tau=0.25', '\tau=0.5', ...
    '\tau=0.75', '\tau=0.9', '\tau=0.95', '\tau=0.975', 'Location', 'NorthWest')

% Crossed
z = [x0b(:)'; z_cr];
z = sortrows(z', 1)';
z = z(2 : (n_tau + 1), :);
plot(sort(x0b)', z(1, :), 'k+-')
hold on
plot(sort(x0b)', z(2, :), 'kx--')
hold on
plot(sort(x0b)', z(3, :), 'k^-.')
hold on
plot(sort(x0b)', z(4, :), 'ks-')
hold on
plot(sort(x0b)', z(5, :), 'ko--')
hold on
plot(sort(x0b)', z(6, :), 'kd-.')
hold on
plot(sort(x0b)', z(7, :), 'k*-')
hold on
plot(sort(x0b)', z(8, :), 'kd--')
hold on
plot(sort(x0b)', z(9, :), 'k^-.')
hold off
xlabel('x^T\beta')
ylabel('y')
title('Different Conditional Quantile Curves (Non-constraint QR)')
legend('\tau=0.025', '\tau=0.05', '\tau=0.1', '\tau=0.25', '\tau=0.5', ...
    '\tau=0.75', '\tau=0.9', '\tau=0.95', '\tau=0.975', 'Location', 'NorthWest')
%}
