function preds = PredNonCross(x0b, tau, lambda, knots_x, knots_tau, order_x, order_tau)
% Given control points lambda and dimension reduction subspace beta to make
%   predictions at some specific quantile levels on the pre-chosen points
%   x0.
%   
%
% Parameters:
% -----------
% x0b: N x q matrix
%     predictors
% tau: kn x 1 vector
%     quantile levels
% lambda: (j1^q * j2) x 1 vector
%     control points of tensor product b-spline
% knots_x: j1 x q matrix
%     knots sequences for XB
% knots_tau: j2 x 1 vector
%     knots sequence for tau
% order_x: integer
%     b-spline orders for XB
% order_tau: integer
%     b-spline order for tau
%
% Retrun:
% -------
% pred: m x n matrix
%     predictions
%

[n, dim] = size(x0b);
m = length(tau);
nknots_x = length(knots_x);
ncol_x = nknots_x + order_x - 2; 

if(dim == 1)                                                               % obtain design matrix using specified knots sequence
    [bas1, ~] = bs(order_x, knots_x, x0b);
    [des_tau, ~] = bs(order_tau, knots_tau, tau);
    designs = kron(bas1, des_tau);
else
    [bas1, ~] = bs(order_x, knots_x(:, 1), x0b(:, 1));
    [bas2, ~] = bs(order_x, knots_x(:, 2), x0b(:, 2));
    designs = zeros(n, ncol_x ^ dim);
    for i = 1 : n
        designs(i, :) = kron(bas1(i, :), bas2(i, :));
    end
    [des_tau, ~] = bs(order_tau, knots_tau, tau);                          
    designs = kron(designs, des_tau);
end

z = designs * lambda;
preds = reshape(z, [m, n]);
end