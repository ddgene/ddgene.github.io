function [Basis,Sigval] = SIR(x, y, type, nslices, dim)

% [Basis,Sigval] = SIR(x,y,type, nslices,dim)
% 
% This function implements the sliced inverse regression procedure for 
% sufficient dimensionality reduction (Li 1991).
%
% USAGE:
%   - outputs:
%     Basis: basis directions of the central subspace
%     Sigval:  singular values of the kernel matrix.
%   - inputs:
%     y: response vector [n q].
%     x: predictors matrix [n, p].
%     type: with value 'cont' or 'disc', specifies that the response Y is continuous 
%     or discrete (in which case it is a regression problem) while with value 'cate' it
%     specifies a categorical response (and a classification problem).
%     nslices: to set the number of slices to be used to discretize continuous responses.
%     dim: desired dimension for the central subspace.
%
% --------------------------------- REFERENCES -----------------------------------
% Li, K. C. (1991). Sliced inverse regression for dimension reduction (with discussion).
%     Journal of the American Statistical Association 86, 316--342.
%
% ================================================================================

%--------checking required arguments..............................................
if nargin < 5,
    error('Not enough input arguments. Type >>help SIR for details');
end
if (nargout > 2)
   error('Too many output arguments.')
end

if ~strcmpi(type,'cont') && ~strcmpi(type,'disc') && ~strcmpi(type,'cate'),
    error('unknown type of response. Valid options are CONTinuous or DISCrete or CATEgorical...');
end
if ~ischar(dim) && dim ~= fix(dim),
    error('Natural value expected to specify reduced subspace dimension.');
end
if ~ischar(nslices) && dim ~= fix(dim),
    error('Natural value expected to specify the number of slices.');
end
if ~isreal(y),
    error('Response vector must be numeric');
end
% .........................................................................


[n, p] = size(x);
mean_value = zeros(nslices, p);
if strcmpi(type,'cont') || strcmpi(type,'disc'),
    bin_point = prctile(y,0:fix(100/nslices):100);
    for ii = 1:nslices
        index = find(y>= bin_point(ii)  & y<= bin_point(ii+1));
        if length(index) <= 1
            return;
        end
        mean_value(ii,:) = mean(x(index,:),1) - mean(x,1);
    end
elseif strcmpi(type,'cate'),
    bin_point = unique(y);
    for ii = 1:length(bin_point)
        index = find(y == bin_point(ii));
        pii = length(index)/n;
        if length(index) <= 1
            error('Is the type of response misspecified?');
        end
        mean_value(ii,:) = (mean(x(index,:),1) - mean(x,1))/sqrt(pii);
    end
end
Tmp = (inv(cov(x,1)))^(0.5);
[U,S,~] = svd(Tmp*cov(mean_value)*Tmp);
Basis = Tmp*U(:,1:dim);
Sigval = diag(S);







