% 2-index
dat = xlsread('04cars.xls');                                               % read data
data = dat;

q = 2;                                                                     % single index / multiple index
[rows, ~] = find(isnan(data));                                             % find nan
data(rows, :) = [];
[rows, ~] = find(data(:, 5) == 1);                                         % find pickup trucks
data(rows, :) = [];
y = data(:, 8);
y = (y - mean(y)) / std(y);

x = data;
x(:, [5, 8, 9]) = [];                                                      % useful data extraction
n = size(x, 1);
xx = x(:, 7 : 15);
xx = (xx - ones(n, 1) * mean(xx))./ (ones(n, 1) * std(xx));
x = [xx(:, 1), xx(:, 3), xx(:, 2), xx(:, 4 : 9), x(:, 1 : 6)];
clear xx dat

nknots_x = 6;                                                              % tensor product spline setting
nknots_tau = 6;
order_x = 4;
order_tau = 4;
kn = 10;       
tau_up = 0.99;                                                             % specify quantile levels
tau_low = 0.01;
tau = linspace(tau_low, tau_up, kn)';

tau_pred = [0.025, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.975]';         % specify prediction quantile levels
n_tau = length(tau_pred);

beta = dMAVE(x, y, q);                                              % dimension reduction for single-index vector
%beta = CUME(x, y, 'cont', q);
beta = beta / beta(1 : 2, 1 : 2);
xb = x * beta;

% Using dMAVE's results to compare different methods
s = linspace(0, 1, nknots_x);                                              % sepcify knots sequence
knots_x = quantile(xb, s);
s = linspace(0, 1, nknots_tau);
knots_tau = quantile(tau, s);

n_x = 10;
s = linspace(0.01, 0.99, n_x);
x0 = quantile(x, s);
x0b = x0 * beta;

[x01, x02] = meshgrid(x0b(:, 1), x0b(:, 2));
x00b = [x01(:), x02(:)];

lambda_my = NonCross(x, y, tau, beta, knots_x, knots_tau, order_x, order_tau);% estimate the control points
z_my = PredNonCross(x00b, tau_pred, lambda_my, knots_x, knots_tau, order_x, order_tau);

lambda_cr = SQR(x, y, tau, beta, knots_x, knots_tau, order_x, order_tau);
z_cr = PredNonCross(x00b, tau_pred, lambda_cr, knots_x, knots_tau, order_x, order_tau);
