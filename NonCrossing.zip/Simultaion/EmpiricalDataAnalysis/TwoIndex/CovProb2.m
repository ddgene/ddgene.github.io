dat = xlsread('04cars.xls');                                               % read data
data = dat;

q = 2;                                                                     % single index / multiple index
[rows, ~] = find(isnan(data));                                             % find nan
data(rows, :) = [];
[rows, ~] = find(data(:, 5) == 1);                                         % find pickup trucks
data(rows, :) = [];
y = data(:, 8);
y = (y - mean(y)) / std(y);

x = data;
x(:, [5, 8, 9]) = [];                                                      % useful data extraction
n = size(x, 1);
xx = x(:, 7 : 15);
xx = (xx - ones(n, 1) * mean(xx))./ (ones(n, 1) * std(xx));
x = [xx, x(:, 1 : 6)];
%x = [xx(:, 1), xx(:, 3), xx(:, 2), xx(:, 4 : 9), x(:, 1 : 6)];
clear xx dat

nknots_x = 8;                                                              % tensor product spline setting
nknots_tau = 8;
order_x = 4;
order_tau = 4;
kn = 20;       
tau_up = 0.99;                                                             % specify quantile levels
tau_low = 0.01;
tau = linspace(tau_low, tau_up, kn)';

tau_pred = [0.025, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.975]';         % specify prediction quantile levels
n_tau = length(tau_pred);

%% for coverage probability
% Proposed Method Results
Pcount95 = 0;
Pcount90 = 0;
Plen95 = zeros(1, n);
Plen90 = zeros(1, n);

% Non-constraint Methods Results
Ccount95 = 0;
Ccount90 = 0;
Clen95 = zeros(1, n);
Clen90 = zeros(1, n);

tau95 = [0.025, 0.975]';
tau90 = [0.05, 0.95]';

B = zeros(30, n);

h = waitbar(0, 'Please wait...');
for i = 1 : n
    xx = x;
    xx(i, :) = [];
    x00 = x(i, :);
    yy = y;
    yy(i) = [];
    y00 = y(i);
    
    beta_hat = dMAVE(xx, yy, q);
    %beta_hat = CUME(xx, yy, 'cont', q);
    %beta_hat = beta_hat / beta_hat(1 : 2, 1 : 2);
    B(:, i) = beta_hat(:);
    xxb = xx * beta_hat;
    x00b = x00 * beta_hat;
    
    
    s = linspace(0, 1, nknots_x);                                          % spline knots setting
    knots_x = quantile(xxb, s);
    s = linspace(0, 1, nknots_tau);
    knots_tau = quantile(tau, s);
    
    % Proposed Method
    lambda_est = NonCross(xx, yy, tau, beta_hat, knots_x, knots_tau, order_x, order_tau);
    z_95 = PredNonCross(x00b, tau95, lambda_est, knots_x, knots_tau, ...
        order_x, order_tau);                                               % 95% predicting
    if(y00 >= z_95(1) && y00 <= z_95(2))
        Pcount95 = Pcount95 + 1;
    end
    Plen95(i) = z_95(2) - z_95(1);
    
    z_90 = PredNonCross(x00b, tau90, lambda_est, knots_x, knots_tau, ...
        order_x, order_tau);                                               % 90% predicting
    if(y00 >= z_90(1) && y00 <= z_90(2))
        Pcount90 = Pcount90 + 1;
    end
    Plen90(i) = z_90(2) - z_90(1);
    
    % Non-constraint QR
    lambda_crr = SQR(xx, yy, tau, beta_hat, knots_x, knots_tau, order_x, order_tau);
    zz_95 = PredNonCross(x00b, tau95, lambda_crr, knots_x, knots_tau, ...
        order_x, order_tau);                                               % 95% predicting
    if(y00 >= zz_95(1) && y00 <= zz_95(2))
        Ccount95 = Ccount95 + 1;
    end
    Clen95(i) = zz_95(2) - zz_95(1);
    
    zz_90 = PredNonCross(x00b, tau90, lambda_crr, knots_x, knots_tau, ...
        order_x, order_tau);                                               % 90% predicting
    if(y00 >= zz_90(1) && y00 <= zz_90(2))
        Ccount90 = Ccount90 + 1;
    end
    Clen90(i) = zz_90(2) - zz_90(1);
    
    perc = round(i * 100 / n);
    waitbar(perc / 100, h, sprintf('Simulation progress: %d%% done.', perc))
end
close(h) 
save('dMAVE_2_0228(2).mat')
covprob = [Pcount95 / n, Ccount95 / n;
           Pcount90 / n, Ccount90 / n];
len = [mean(Plen95), mean(Clen95);
       mean(Plen90), mean(Clen90)];
lensd = [std(Plen95), std(Clen95);
         std(Plen90), std(Clen90)] / sqrt(n);
Output = [1 0;
          0 0;
          0 1;
          0 0] * covprob + [0 0;
                            1 0;
                            0 0;
                            0 1] * len;