function quantiles = ncnp(xb, y, x0b, tau, kern_r, hr, kern_d, hd, N)
% INPUT: 
% X: Predictor Obs for training
% Y: Response Obs for training
% Both X and Y must be of the same length, say, n x 1;
% tau: the quantile leveles, k x 1;
% dist: the probability objective for the distribution G
% hr: the bandwidth for Kern_r, k x 1;
% hd: the bandwidth for Kern_d, k x 1;
% N: number of knots for smoothing > 2;
% kern is the kernal to be used. Options: "Gaussian", "Quartic", "Epanechnikov"

% OUTPUT:
% quantiles: returned quantiles at levels indicated by the variable tau

sizex = length(x0b);
sizet = length(tau);

z = linspace(1, N - 1, N - 1);
z = z / N;
y0 = zeros(N - 1, sizex);
quantiles = zeros(sizet, sizex);

a0 = zeros(sizex, 1);
b0 = zeros(sizex, 1);

for ii = 1 : sizet
    for kk = 1 : sizex
        ab = abs(xb - x0b(kk));
        ys = y;
        if(length(ys(ab <= hd(ii))) < 20)                                   % not enough points in neighborhood
            l = 20;
            tmp = [ab, ys];
            tmp = sortrows(tmp, 1);
            tmp = tmp(1 : l, :);
            %hd(ii) = max(tmp(:, 1));                                       % recalculate the bandwidth
            ys = sort(tmp(:, 2));
            b0(kk) = (ys(floor(0.99 * l)) - ys(floor(1 + 0.01 * l))) / (norminv(0.99) - norminv(0.01));
            a0(kk) = ys(floor(0.99 * l)) - b0(kk) * norminv(0.99);
        else
            ys(ab >= hd(ii)) = [];
            ys = sort(ys);
            l = length(ys);
            b0(kk) = (ys(floor(0.99 * l)) - ys(floor(1 + 0.01 * l))) / (norminv(0.99) - norminv(0.01));
            a0(kk) = ys(floor(0.99 * l)) - b0(kk) * norminv(0.99);
        end
        y0(:, kk) = icdf('Normal', z', a0(kk), b0(kk));
    end
    
    values = CondDistFuncEst(xb, y, x0b, y0, hr(ii), kern_r);
    values = [values; ones(1, sizex)];
    u = (tau(ii) - values) / hd(ii);                                  
    if(strcmp(kern_d, 'Epanechnikov'))
        u(u - 1 >= 0) = 1;
        u(u + 1 <= 0) = -1;
        Hinv = mean((1/2 + (3/4).* (u - (1/3).* u.^ 3)), 1);               % Epanechnikov
    else
        Hinv = mean(normcdf(u), 1);                                        % Gauss kernerl for Kd
    end
    Hinv(Hinv > 0.99) = 0.99;
    Hinv(Hinv < 0.01) = 0.01;
    for kk = 1 : sizex
        quantiles(ii, kk) = icdf('Normal', Hinv(kk), a0(kk), b0(kk));
    end
end
end