load('AddSingleM21.mat')
MSE = zeros(n_tau, 7);
SD = zeros(n_tau, 7);
MSE(:, 1) = mean(MSEcr, 2);
MSE(:, 2) = mean(MSEprop, 2);
MSE(:, 3) = mean(MSEora, 2);
MSE(:, 4) = mean(MSEcomp, 2);
MSE(:, 5) = mean(MSEcomp_ora, 2);
MSE(:, 6) = mean(MSEcompCher, 2);
MSE(:, 7) = mean(MSEcompCher_ora, 2);

SD(:, 1) = std(MSEcr, 0, 2)./ sqrt(MCnum);
SD(:, 2) = std(MSEprop, 0, 2)./ sqrt(MCnum);
SD(:, 3) = std(MSEora, 0, 2)./ sqrt(MCnum);
SD(:, 4) = std(MSEcomp, 0, 2)./ sqrt(MCnum);
SD(:, 5) = std(MSEcomp_ora, 0, 2)./ sqrt(MCnum);
SD(:, 6) = std(MSEcompCher, 0, 2)./ sqrt(MCnum);
SD(:, 7) = std(MSEcompCher_ora, 0, 2)./sqrt(MCnum);

Output = MSE * [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 
                0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 
                0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0;
                0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0;
                0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0;
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0;
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0] ...
                + SD * [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 
                        0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0; 
                        0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0;
                        0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0;
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0;
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0;
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1];
Output = [tau_pred, Output];
fid = fopen('addsingle13.txt','w');
fprintf(fid,'& %g & %.3f (%.3f) & %.3f (%.3f) & %.3f (%.3f) & %.3f (%.3f) & %.3f (%.3f) & %.3f (%.3f) & %.3f (%.3f)\r\n', Output');
fclose(fid); 

set(gcf, 'PaperUnits', 'centimeters')
set(gcf, 'Position', [100 100 600 500])
z = [x0b(:)'; z_my];
z = sortrows(z', 1)';
z = z(2 : (n_tau + 1), :);
for i = 1 : (n_tau - 1)
    plot(sort(x0b)', z(i, :))
    hold on
end
plot(sort(x0b)', z(n_tau, :))
hold off
xlabel('x^T\beta')
ylabel('y')
title('Different Conditional Quantile Curves(Case 1)')
legend('\tau=0.1', '\tau=0.25', '\tau=0.5', '\tau=0.75', '\tau=0.9', ...
    'Location', 'NorthWest')
clear


load('multi3_123.mat')
MPEprop1 = MPEprop;
MPEcr1 = MPEcr;
MPEora1 = MPEora;

load('multi3_456.mat')
MPEprop2 = MPEprop;
MPEcr2 = MPEcr;
MPEora2 = MPEora;

PROP = [MPEprop1, MPEprop2];
CR = [MPEcr1, MPEcr2];
ORA = [MPEora1, MPEora2];

MPE = zeros(n_tau, 3);
SD = zeros(n_tau, 3);


MPE(:, 1) = mean(CR, 2);
MPE(:, 2) = mean(PROP, 2);
MPE(:, 3) = mean(ORA, 2);

[~, M] = size(PROP);

SD(:, 1) = std(CR, 0, 2)./ sqrt(M);
SD(:, 2) = std(PROP, 0, 2)./ sqrt(M);
SD(:, 3) = std(ORA, 0, 2)./ sqrt(M);

Output = MPE * [1, 0, 0, 0, 0, 0; 
                0, 0, 1, 0, 0, 0; 
                0, 0, 0, 0, 1, 0] + SD * [0, 1, 0, 0, 0, 0; 
                                          0, 0, 0, 1, 0, 0; 
                                          0, 0, 0, 0, 0, 1];
Output = [tau_pred, Output];
fid = fopen('multi3.txt','w');
fprintf(fid,'& %g & %.3f (%.3f) & %.3f (%.3f) & %.3f (%.3f)\r\n', Output');
fclose(fid); 
clear

subplot(1, 2, 1)
set(gcf, 'PaperUnits', 'centimeters')
set(gcf, 'Position', [100 100 600 500])
prop = reshape(z_my(1, :), [n_x, n_x]);
prop = [x0b(:, 1)'; prop];
prop = sortrows(prop', 1)';
prop = prop(2 : (n_x + 1), :);
prop = [x0b(:, 2), prop];
prop = sortrows(prop, 1);
prop = prop(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), prop, 'FaceColor', [160, 0, 2] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

prop = reshape(z_my(2, :), [n_x, n_x]);
prop = [x0b(:, 1)'; prop];
prop = sortrows(prop', 1)';
prop = prop(2 : (n_x + 1), :);
prop = [x0b(:, 2), prop];
prop = sortrows(prop, 1);
prop = prop(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), prop, 'FaceColor', [255, 204, 0] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

prop = reshape(z_my(3, :), [n_x, n_x]);
prop = [x0b(:, 1)'; prop];
prop = sortrows(prop', 1)';
prop = prop(2 : (n_x + 1), :);
prop = [x0b(:, 2), prop];
prop = sortrows(prop, 1);
prop = prop(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), prop, 'FaceColor', [255, 137, 3] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

prop = reshape(z_my(4, :), [n_x, n_x]);
prop = [x0b(:, 1)'; prop];
prop = sortrows(prop', 1)';
prop = prop(2 : (n_x + 1), :);
prop = [x0b(:, 2), prop];
prop = sortrows(prop, 1);
prop = prop(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), prop, 'FaceColor', [252, 241, 3] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

prop = reshape(z_my(5, :), [n_x, n_x]);
prop = [x0b(:, 1)'; prop];
prop = sortrows(prop', 1)';
prop = prop(2 : (n_x + 1), :);
prop = [x0b(:, 2), prop];
prop = sortrows(prop, 1);
prop = prop(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), prop, 'FaceColor', [135, 206, 240] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

prop = reshape(z_my(6, :), [n_x, n_x]);
prop = [x0b(:, 1)'; prop];
prop = sortrows(prop', 1)';
prop = prop(2 : (n_x + 1), :);
prop = [x0b(:, 2), prop];
prop = sortrows(prop, 1);
prop = prop(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), prop, 'FaceColor', [51, 153, 254] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

prop = reshape(z_my(7, :), [n_x, n_x]);
prop = [x0b(:, 1)'; prop];
prop = sortrows(prop', 1)';
prop = prop(2 : (n_x + 1), :);
prop = [x0b(:, 2), prop];
prop = sortrows(prop, 1);
prop = prop(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), prop, 'FaceColor', [0, 97, 156] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

prop = reshape(z_my(8, :), [n_x, n_x]);
prop = [x0b(:, 1)'; prop];
prop = sortrows(prop', 1)';
prop = prop(2 : (n_x + 1), :);
prop = [x0b(:, 2), prop];
prop = sortrows(prop, 1);
prop = prop(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), prop, 'FaceColor', [92, 167, 186] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

prop = reshape(z_my(9, :), [n_x, n_x]);
prop = [x0b(:, 1)'; prop];
prop = sortrows(prop', 1)';
prop = prop(2 : (n_x + 1), :);
prop = [x0b(:, 2), prop];
prop = sortrows(prop, 1);
prop = prop(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), prop, 'FaceColor', [28, 120, 135] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold off

xlabel('x^T\beta_1')
ylabel('x^T\beta_2')
zlabel('y')
legend('\tau=0.025', '\tau=0.05', '\tau=0.1', '\tau=0.25', '\tau=0.5', ...
    '\tau=0.75', '\tau=0.9', '\tau=0.95','\tau=0.975', 'Location', 'SouthWest')
title('Non-crossing Quantile Sufaces for Proposed Method')


subplot(1, 2, 2)
set(gcf, 'PaperUnits', 'centimeters')
set(gcf, 'Position', [100 100 600 500])
cr = reshape(z_cr(1, :), [n_x, n_x]);
cr = [x0b(:, 1)'; cr];
cr = sortrows(cr', 1)';
cr = cr(2 : (n_x + 1), :);
cr = [x0b(:, 2), cr];
cr = sortrows(cr, 1);
cr = cr(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), cr, 'FaceColor', [160, 0, 2] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

cr = reshape(z_cr(2, :), [n_x, n_x]);
cr = [x0b(:, 1)'; cr];
cr = sortrows(cr', 1)';
cr = cr(2 : (n_x + 1), :);
cr = [x0b(:, 2), cr];
cr = sortrows(cr, 1);
cr = cr(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), cr, 'FaceColor', [255, 204, 0] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

cr = reshape(z_cr(3, :), [n_x, n_x]);
cr = [x0b(:, 1)'; cr];
cr = sortrows(cr', 1)';
cr = cr(2 : (n_x + 1), :);
cr = [x0b(:, 2), cr];
cr = sortrows(cr, 1);
cr = cr(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), cr, 'FaceColor', [255, 137, 3] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

cr = reshape(z_cr(4, :), [n_x, n_x]);
cr = [x0b(:, 1)'; cr];
cr = sortrows(cr', 1)';
cr = cr(2 : (n_x + 1), :);
cr = [x0b(:, 2), cr];
cr = sortrows(cr, 1);
cr = cr(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), cr, 'FaceColor', [252, 241, 3] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

cr = reshape(z_cr(5, :), [n_x, n_x]);
cr = [x0b(:, 1)'; cr];
cr = sortrows(cr', 1)';
cr = cr(2 : (n_x + 1), :);
cr = [x0b(:, 2), cr];
cr = sortrows(cr, 1);
cr = cr(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), cr, 'FaceColor', [135, 206, 240] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

cr = reshape(z_cr(6, :), [n_x, n_x]);
cr = [x0b(:, 1)'; cr];
cr = sortrows(cr', 1)';
cr = cr(2 : (n_x + 1), :);
cr = [x0b(:, 2), cr];
cr = sortrows(cr, 1);
cr = cr(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), cr, 'FaceColor', [51, 153, 254] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

cr = reshape(z_cr(7, :), [n_x, n_x]);
cr = [x0b(:, 1)'; cr];
cr = sortrows(cr', 1)';
cr = cr(2 : (n_x + 1), :);
cr = [x0b(:, 2), cr];
cr = sortrows(cr, 1);
cr = cr(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), cr, 'FaceColor', [0, 97, 156] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

cr = reshape(z_cr(8, :), [n_x, n_x]);
cr = [x0b(:, 1)'; cr];
cr = sortrows(cr', 1)';
cr = cr(2 : (n_x + 1), :);
cr = [x0b(:, 2), cr];
cr = sortrows(cr, 1);
cr = cr(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), cr, 'FaceColor', [92, 167, 186] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold on

cr = reshape(z_cr(9, :), [n_x, n_x]);
cr = [x0b(:, 1)'; cr];
cr = sortrows(cr', 1)';
cr = cr(2 : (n_x + 1), :);
cr = [x0b(:, 2), cr];
cr = sortrows(cr, 1);
cr = cr(:, 2 : (n_x + 1));
surf(sort(x0b(:, 1)), sort(x0b(:, 2)), cr, 'FaceColor', [28, 120, 135] / 255, 'EdgeColor', [255, 255, 255] / 255), grid on
hold off

xlabel('x^T\beta_1')
ylabel('x^T\beta_2')
zlabel('y')
legend('\tau=0.025', '\tau=0.05', '\tau=0.1', '\tau=0.25', '\tau=0.5', ...
    '\tau=0.75', '\tau=0.9', '\tau=0.95','\tau=0.975', 'Location', 'SouthWest')
title('Crossed Quantile Sufaces for Non-constraint Method')
