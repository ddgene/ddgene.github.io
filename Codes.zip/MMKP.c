#include <R.h>
#include <Rinternals.h>
#include <math.h>
#include <Rmath.h>
#include <stdio.h>
#include <stdlib.h>
#define eps 10e-10
#define epsilon 10e-200
//#define MaxIter 1000
//#define MaxIter1 1000
void bsort(double* q,int n) //bubble sort
{
   int i,j;
   double temp;
   for( i=0;i<n;i++)
    for(j=n-1;j>i;j--)
    {
        if(q[j]>q[j-1])
        {
           temp=q[j-1];
           q[j-1]=q[j];
           q[j]=temp;
        }
    }
}

double fabs1(double x)
{
    if (x>=0) return x;
    else return -x;
}

int ceil1(double x)
{
    if(x-(int)x>eps)return((int)x+1);
    else return((int)x);
}

int intmax(int x,int y)
{
    if(x>y)return(x);
    else return(y);
}

int findmax(double *q,int n)
{
	int i,j;
	double qmax;
	qmax=q[0];
	j=0;
	for(i=1;i<n;i++)
	{
		if(q[i]>qmax)
		{
			qmax=q[i];
			j=i;
		}
	}
	return j;
}

void CP(double*D_star,double c1,int*Z,int c2,int*V_star,int Rnum,int Cnum,int*Delta,int*sol)
{
     double*U,temp;
     double R1;
     int*index,R2;
     int i,j,j1,k0,i0;
     U=(double*)malloc(Cnum*Rnum*sizeof(double));
     index=(int*)malloc(Rnum*sizeof(int));
     /*Initialization*/
     R1=0.0;R2=0;
     for(i=0;i<Rnum;i++){
        temp=0;
        j1=0;
        for(j=0;j<Cnum;j++){
            if(V_star[i*Cnum+j]==0){U[i*Cnum+j]=0;}
            else{U[i*Cnum+j]=V_star[i*Cnum+j]/(D_star[i*Cnum+j]*c1+Z[i*Cnum+j]*c2);}
            if(U[i*Cnum+j]>temp){temp=U[i*Cnum+j];j1=j;}
        }
        temp=0;
        index[i]=j1;
        Delta[i*Cnum+j1]=1;
        R1+=D_star[i*Cnum+j1];
        R2+=Z[i*Cnum+j1];
     }
     /*Main steps*/
     while(R1>c1 || R2>c2){
          if(R1>R2){k0=0;}
          else {k0=1;}
          i0=Rnum-1;
          if(k0<1){
              temp=D_star[i0*Cnum+index[i0]];
              for(i=0;i<Rnum;i++){
                    if(D_star[i*Cnum+index[i]]>temp)
                    {temp=D_star[i*Cnum+index[i]];i0=i;}
              }
          }
          else{
               temp=Z[i0*Cnum+index[i0]];
               for(i=Rnum-1;i>=0;i--){
                  if(Z[i*Cnum+index[i]]>temp)
                  {temp=Z[i*Cnum+index[i]];i0=i;}
               }
          }
          Delta[i0*Cnum+index[i0]]=0;
          R1-=D_star[i0*Cnum+index[i0]];
          R2-=Z[i0*Cnum+index[i0]];
          j=Cnum-1;
          while((abs(j-index[i0])<.5 || R1+D_star[i0*Cnum+j]>c1 || R2+Z[i0*Cnum+j]>c2)&& j>0){
             j--;
          }
          Delta[i0*Cnum+j]=1;
          index[i0]=j;
          R1+=D_star[i0*Cnum+j];
          R2+=Z[i0*Cnum+j];
     }
     for(i=0;i<Rnum;i++)sol[i]=index[i];
     free(U);
     free(index);
}

void CCP(double*D_star,double c1,int*Z,int c2,int*V_star,int Rnum,int Cnum,int*Delta,int*sol,int*List,int num,int MaxIter)
{
     //int*sol_star;
     int i,j,iter,rank,s;
     double R1;//,temp,temp1;
     int tabu,R2;
     //sol_star=(int*)malloc(Rnum*sizeof(int));
     tabu=0;
     if(num<1){tabu=1;}
     else{
         i=0;
         while(i<num&&tabu<1){
              rank=0;
              for(j=0;j<Rnum;j++)
              {
                  rank+=abs(List[i*Rnum+j]-sol[j]);
              }
              if(rank<1)tabu=1;
              i++;
         }
     }
     if(tabu<1){
       iter=0;
       R1=0.0;R2=0;
       for(j=0;j<Rnum;j++){
           //sol_star[j]=sol[j];
           R1+=D_star[j*Cnum+sol[j]];
           R2+=Z[j*Cnum+sol[j]];
       }
       while(iter<MaxIter){
         for(i=Rnum-1;i>=0;i--){
            rank=V_star[i*Cnum+sol[i]];
            s=sol[i];
            for(j=0;j<Cnum;j++){
               if(V_star[i*Cnum+j]>rank && R1-D_star[i*Cnum+sol[i]]+D_star[i*Cnum+j]<=c1&&R2-Z[i*Cnum+sol[i]]+Z[i*Cnum+j]<=c2)
               {
                  rank=V_star[i*Cnum+j];
                  s=j;
               }
            }
            //sol_star[i]=s;
            /*temp=temp1=0;
            for(i=0;i<Rnum;i++)
            {
               temp+=V_star[i*Cnum+sol_star[i]];
               temp1+=V_star[i*Cnum+sol[i]];
            }*/
            //if(temp>temp1){
            R1=R1-D_star[i*Cnum+sol[i]]+D_star[i*Cnum+s];
            R2=R2-Z[i*Cnum+sol[i]]+Z[i*Cnum+s];
            Delta[i*Cnum+sol[i]]=0;
            sol[i]=s;
            Delta[i*Cnum+sol[i]]=1;
            //}
         }
         iter++;
       }
     }
     //free(sol_star);
}

int GetClass(int maxNum)
{
    double x;
    int num;
    x=runif(0,maxNum);
    num=(int)x;
    if(num>maxNum-1)num=maxNum-1;
    return(num);
}

void Degrader(double*D_star,double c1,int*Z,int c2,int*V_star,int Rnum,int Cnum,int*Delta,int*sol,int MaxIter)
{
     int i,j,s,iter,exit,iter1;
     double R1;
     int R2;
     iter=0;
     while(iter<MaxIter){
          R1=0.0;
          R2=0;
          for(i=0;i<Rnum;i++){
            R1+=D_star[i*Cnum+sol[i]];
            R2+=Z[i*Cnum+sol[i]];
          }
          i=GetClass(Rnum);
          s=sol[i];
          //for(j=0;j<Cnum;j++)
          //j=Cnum-1;
          j=GetClass(Cnum);
          exit=0;
          iter1=0;
          while(exit<1&&iter1<MaxIter)
          {
               if(R1-D_star[i*Cnum+s]+D_star[i*Cnum+j]<=c1 && R2-Z[i*Cnum+s]+Z[i*Cnum+j]<=c2)
               {
                  Delta[i*Cnum+sol[i]]=0;
                  sol[i]=j;
                  Delta[i*Cnum+sol[i]]=1;
                  exit=1;
               }
               j=GetClass(Cnum);
               iter1++;
          }
          iter++;
     }
}

int obj(int*V_star,int Rnum,int Cnum,int*sol){
    int i;
    int rank;
    rank=0;
    for(i=0;i<Rnum;i++)rank+=V_star[i*Cnum+sol[i]];
    return(rank);
}

double MRLS(double*D_star,double c1,int*Z,double c2,int*V_star,int Rnum,int Cnum,int*Delta,int*sol, int MaxIter)
{
     int*sol_star,*sol_prime,*List,*List1;
     int i,j,iter;
	 double LB1;
     sol_star=(int*)malloc(Rnum*sizeof(int));
     sol_prime=(int*)malloc(Rnum*sizeof(int));
     iter=0;
     List=(int*)malloc(Rnum*sizeof(int));
     for(i=0;i<Rnum;i++){
        sol_star[i]=sol[i];
     }
     while(iter<MaxIter){
           CCP(D_star,c1,Z,c2,V_star,Rnum,Cnum,Delta,sol,List,iter,MaxIter);
           for(i=0;i<Rnum;i++){
               sol_prime[i]=sol[i];
           }
           if(obj(V_star,Rnum,Cnum,sol_prime)>=obj(V_star,Rnum,Cnum,sol_star)){
               for(i=0;i<Rnum;i++){
                   sol_star[i]=sol_prime[i];
               }
           }
           if(iter>0){
              List1=(int*)malloc(iter*Rnum*sizeof(int));
              for(i=0;i<iter;i++){
                 for(j=0;j<Rnum;j++)List1[i*Rnum+j]=List[i*Rnum+j];
              }
              free(List);
              iter++;
              List=(int*)malloc(iter*Rnum*sizeof(int));
              for(i=0;i<iter;i++){
                 if(i<iter-1){
                    for(j=0;j<Rnum;j++)List[i*Rnum+j]=List1[i*Rnum+j];
                 }
                 else{
                    for(j=0;j<Rnum;j++)List[i*Rnum+j]=sol_prime[j];
                 }
              }
              free(List1);
           }
           else{
              for(i=0;i<Rnum;i++)List[i]=sol_prime[i];
              iter++;
           }
           for(i=0;i<Rnum;i++){
              for(j=0;j<Cnum;j++)
              {
                  Delta[i*Cnum+j]=0;
              }
              sol[i]=sol_star[i];
              Delta[i*Cnum+sol[i]]=1;
           }
           Degrader(D_star,c1,Z,c2,V_star,Rnum,Cnum,Delta,sol,MaxIter);
     }
     LB1=0;
	 for(i=0;i<Rnum;i++){
        for(j=0;j<Cnum;j++)
        {
            Delta[i*Cnum+j]=0;
        }
        sol[i]=sol_star[i];
        Delta[i*Cnum+sol[i]]=1;
		LB1+=V_star[i*Cnum+sol[i]];
     }
     free(List);
     free(sol_star);
     free(sol_prime);
     return LB1;
}

double UB(double*D_star,double c1,int*Z,double c2,int*V_star,int Rnum,int Cnum)
{
	int *index,i,j;
    double *w,*vw, *tempv, *vw1,  R_max, V_max, UB1, C, temp,v1,w1,ubd;
	w=(double*)malloc(Rnum*Cnum*sizeof(double));
	vw=(double*)malloc(Rnum*Cnum*sizeof(double));
    tempv=(double*)malloc(Rnum*Cnum*sizeof(double));
	vw1=(double*)malloc(Rnum*sizeof(double));
    index=(int*)malloc(Rnum*sizeof(int));
	C=c1+c2;
	for(i=0;i<Rnum*Cnum;i++)
	{
		w[i]=D_star[i]+(double)(Z[i]);
		tempv[i]=V_star[i];
		if(fabs(w[i])>1e-5)
		{
		    vw[i]=V_star[i]/w[i];
		}
		else
		{
			vw[i]=0;
		}
	}
	R_max=0;
	V_max=0;
	j=0;
	for(i=0;i<Rnum;i++)
	{
        j=findmax(&vw[i*Cnum], Cnum);
		vw1[i]=vw[i*Cnum+j];
		index[i]=j;
	}
	for(i=0;i<Rnum;i++)
	{
		j=findmax(vw1, Rnum);
		R_max+=w[j*Cnum+index[j]];
        V_max+=tempv[j*Cnum+index[j]];
		if(R_max<=C)
		{
		tempv[j*Cnum+index[j]]=0;
		vw[j*Cnum+index[j]]=0;
		w[j*Cnum+index[j]]=0;
		vw1[j]=0;
		}
		else
		{
			i=Rnum;
			R_max-=w[j*Cnum+index[j]];
			V_max-=V_star[j*Cnum+index[j]];
		}
	}



	if(i==Rnum+1)
	{
		UB1=V_max+V_star[j*Cnum+index[j]]/w[j*Cnum+index[j]]*(C-R_max);
	}
	else
	{
		for( i=0;i<Rnum*Cnum;i++)
		{
			for(j=Rnum*Cnum-1;j>i;j--)
			{
				if(vw[j]>vw[j-1])
				{
					temp=vw[j-1];
					vw[j-1]=vw[j];
					vw[j]=temp;
					temp=tempv[j-1];
					tempv[j-1]=tempv[j];
					tempv[j]=temp;
					temp=w[j-1];
					w[j-1]=w[j];
					w[j]=temp;
				}
			}
		}
        v1=0;
		w1=0;
		i=0;
		while((C-R_max>=w1)&&(i<Rnum*(Cnum-1)))
		{
			w1+=w[i];
			v1+=tempv[i];
			i++;
		}
		v1-=tempv[i-1];
		w1-=w[i-1];
		ubd=v1+(C-R_max-w1)/w[i-1]*tempv[i-1];
		UB1=V_max+ubd;
	}
	free(tempv);
	free(vw);
	free(w);
	free(vw1);
	free(index);
	return UB1;
}


int checkfeasible(double*D_star, double c1, int *Z, double c2, int Num_row, int Cnum, int *sol)
{
	int i;
	double c1_used, c2_used;
	c1_used=0;
	c2_used=0;
	for(i=0;i<Num_row;i++)
	{
		c1_used+=D_star[i*Cnum+sol[i]];
		c2_used+=(double)(Z[i*Cnum+sol[i]]);
	}
	if((c1_used<c1)&&(c2_used<c2))
		return 1;
	else return 0;
}










void EMKP(double*D_star,double c1,int*Z,int c2,int*V_star,int Rnum,int Cnum,int*Delta,int*sol,int MaxIter)
{
	int i,j,nm,k,point,k1,k2, k3, total,nnn,tempi;
	int *X,*c2_used, Num_of_sol;
	double *obj_fun,*c1_used, LB, UB1, tempd;
	nm=Rnum;
	if(Cnum>nm) nm=Cnum;
	total=Rnum*Cnum*nm*10;
	X=(int*)malloc(Rnum*total*sizeof(int));
    c1_used=(double*)malloc(total*sizeof(double));
	c2_used=(int*)malloc(total*sizeof(int));
	obj_fun=(double*)malloc(total*sizeof(double));
	Num_of_sol=0;
	for(i=0;i<total;i++)
	{
		c1_used[i]=0;
		c2_used[i]=0;
		obj_fun[i]=0;
		for(j=0;j<Rnum;j++)
		{
			X[i*Rnum+j]=0;
		}
	}

	LB=MRLS(D_star,c1, Z, c2,V_star,Rnum,Cnum,Delta,sol,MaxIter);
	obj_fun[0]=LB;
	Num_of_sol=1;
	for(i=0;i<Rnum;i++)
	{
		X[i]=sol[i];
		c1_used[0]+=D_star[i*Cnum+sol[i]];
		c2_used[0]+=Z[i*Cnum+sol[i]];
	}

	k=1;
    for(j=0;j<Cnum;j++)
	{
		if((D_star[j]<=c1)&&(Z[j]<=c2))
		{
			UB1=UB(&D_star[Cnum],c1-D_star[j],&Z[Cnum],c2-Z[j],&V_star[Cnum],Rnum-1,Cnum);
			if(V_star[j]+UB1>LB)
			{
			    c1_used[k]=D_star[j];
			    c2_used[k]=Z[j];
				obj_fun[k]=V_star[j];
			    X[k*Rnum]=j;
			    k++;
				Num_of_sol++;
			}
		}
	}

    nnn=Num_of_sol;

	for(i=1;i<Rnum-1;i++)
	{
		k=0;
		for(point=1;point<Num_of_sol;point++)
		{
           	for(j=0;j<Cnum;j++)
			{
				if((c1_used[point]+D_star[i*Cnum+j]<=c1)&&(c2_used[point]+Z[i*Cnum+j]<=c2))
				{
					UB1=UB(&D_star[(i+1)*Cnum],c1-c1_used[point]-D_star[i*Cnum+j],&Z[(i+1)*Cnum],c2-c2_used[point]-Z[i*Cnum+j],&V_star[(i+1)*Cnum],Rnum-(i+1),Cnum);
					if(obj_fun[point]+V_star[i*Cnum+j]+UB1>LB)
					{
						c1_used[Num_of_sol+k]=c1_used[point]+D_star[i*Cnum+j];
						c2_used[Num_of_sol+k]=c2_used[point]+Z[i*Cnum+j];
						obj_fun[Num_of_sol+k]=obj_fun[point]+V_star[i*Cnum+j];
						for(k1=0;k1<i;k1++)
						{
							X[(Num_of_sol+k)*Rnum+k1]=X[point*Rnum+k1];
						}
						X[(Num_of_sol+k)*Rnum+i]=j;
						k++;
					}
				}
			}
		}

		Num_of_sol+=k;
		for(k1=point;k1<Num_of_sol;k1++)
		{
			for(k2=0;k2<i+1;k2++)
			{
				X[(k1-point+1)*Rnum+k2]=X[k1*Rnum+k2];
			}
			c1_used[k1-point+1]=c1_used[k1];
			c2_used[k1-point+1]=c2_used[k1];
			obj_fun[k1-point+1]=obj_fun[k1];
		}
        Num_of_sol=k+1;
		//order those solutions in the increasing order of c1_used; if c1_used are the same,
		//then order them in the increasing order of c2_used;
        for(k1=1;k1<Num_of_sol;k1++)
		{
			for(k2=Num_of_sol-1;k2>1;k2--)
			{
				if(c2_used[k2]<c2_used[k2-1])
				{
					tempi=c2_used[k2-1];
					c2_used[k2-1]=c2_used[k2];
					c2_used[k2]=tempi;
					tempd=c1_used[k2-1];
					c1_used[k2-1]=c1_used[k2];
					c1_used[k2]=tempd;
					for(k3=0;k3<i+1;k3++)
					{
						tempi=X[(k2-1)*Rnum+k3];
						X[(k2-1)*Rnum+k3]=X[k2*Rnum+k3];
						X[k2*Rnum+k3]=tempi;
					}
					tempd=obj_fun[k2-1];
					obj_fun[k2-1]=obj_fun[k2];
					obj_fun[k2]=tempd;
				}
				if(c2_used[k2]==c2_used[k2-1])
				{
					if(c1_used[k2]<c1_used[k2-1])
					{
						tempd=c1_used[k2-1];
						c1_used[k2-1]=c1_used[k2];
						c1_used[k2]=tempd;
						for(k3=0;k3<i+1;k3++)
						{
							tempi=X[(k2-1)*Rnum+k3];
							X[(k2-1)*Rnum+k3]=X[k2*Rnum+k3];
							X[k2*Rnum+k3]=tempi;
						}
						tempd=obj_fun[k2-1];
						obj_fun[k2-1]=obj_fun[k2];
						obj_fun[k2]=tempd;
					}
				}
			}
		}
		//prune those non-efficient candidate solutions
		//throw out those candidates using more resource but producing less profit

        for(k1=2;k1<Num_of_sol;k1++)
		{
			if(obj_fun[k1]<=obj_fun[k1-1]&&c2_used[k1]==c2_used[k1-1])
			{
				for(k2=k1+1;k2<Num_of_sol;k2++)
				{
					c1_used[k2-1]=c1_used[k2];
					c2_used[k2-1]=c2_used[k2];
					obj_fun[k2-1]=obj_fun[k2];
					for(k3=0;k3<i+1;k3++)
					{
						X[(k2-1)*Rnum+k3]=X[k2*Rnum+k3];
					}
				}
				Num_of_sol--;
				if(k1!=Num_of_sol-1)
				{
				    k1--;
				}
			}
		}
     }

	 //pick an optimal choice from the last row, that is, calculate the capacities left for c1 and c2, and choose the
	 //item that use as much capacity as possible.
	 for(point=1;point<Num_of_sol;point++)
	 {
		 if(c2_used[point]<=c2-1)
		 {
			 for(j=Cnum-1;j>=0;j--)
			 {
				 if((c1-c1_used[point])>D_star[(Rnum-1)*Cnum+j])
				 {
					 c1_used[point]+=D_star[(Rnum-1)*Cnum+j];
					 c2_used[point]+=Z[(Rnum-1)*Cnum+j];
					 obj_fun[point]+=V_star[(Rnum-1)*Cnum+j];
					 X[(point+1)*Rnum-1]=j;
					 j=-1;
				 }
			 }
		 }
	 }

	 //find the optimal solution
	 point=findmax(obj_fun,Num_of_sol);

	 for(i=0;i<Rnum;i++)
	 {
        for(j=0;j<Cnum;j++)
        {
            Delta[i*Cnum+j]=0;

		}

        sol[i]=X[point*Rnum+i];
        Delta[i*Cnum+sol[i]]=1;



	 }

	 free(X);
	 free(c1_used);
	 free(c2_used);
	 free(obj_fun);
}


SEXP MMKP(SEXP D_Matrix, SEXP NumTrt, SEXP V_Matrix, SEXP NumCont, SEXP Constraint, SEXP Alpha, SEXP MaxIteration,
          SEXP Exact,SEXP rho)
{
      int n,m,m1,num;
      SEXP lists,names,solution;
      //double* x;
      //double* y, *ytrimmed;
      double* D,  *D1,*D_star;
      int* V,*Z, *V_star,*v_bar,*index, *sol;
      int*Delta,*Rank, *Delta_max, *Rank_max;
      double c,alpha,temp;
      int i,j,j1,c1;
      int start;
      int MaxIter,exact;

      m=INTEGER(NumTrt)[0];
      n=INTEGER(NumCont)[0];
	  GetRNGstate();
      alpha=REAL(Alpha)[0];
      if(alpha>eps)num=2*(int)(m*alpha);
      else num=0;
      MaxIter=INTEGER(MaxIteration)[0];
      exact=INTEGER(Exact)[0];
      c=(m-num)*REAL(Constraint)[0];
      c1=m-num;
      m1=m;
      m=m-(int)(m*alpha);
      PROTECT(lists=allocVector(VECSXP,2));
	  PROTECT(names=allocVector(STRSXP,2));
	  //PROTECT(treat=allocVector(REALSXP,m1));
	  PROTECT(solution=allocVector(INTSXP,m1*(n+1)));
      //x=(double*)malloc(n*sizeof(double));
      //y=(double*)malloc(m*sizeof(double));
      //ytrimmed=(double*)malloc(m1*sizeof(double));

      //for(i=0;i<m1;i++)
      //  ytrimmed[i]=REAL(Treatment)[i];
//input the element of array y
      D=(double*)malloc((n+1)*m*sizeof(double));
      D1=(double*)malloc((n+1)*m*sizeof(double));
     //U=(double*)malloc((n+1)*m*sizeof(double));
      Z=(int*)malloc((n+1)*m*sizeof(int));
      V=(int*)malloc((n+1)*m*sizeof(int));
      Delta=(int*)malloc((n+1)*m*sizeof(int));
      Rank=(int*)malloc(sizeof(int));
      Delta_max=(int*)malloc((n+1)*m*sizeof(int));
      Rank_max=(int*)malloc(sizeof(int));
      //for(i=0;i<n;i++){
      //   x[i]=REAL(Control)[i];
      //}
      //bsort(x,n);
      //bsort(ytrimmed,m1);
      //for(i=0;i<m1;i++)
      //{
      //if(i<m1-m){ytrimmed[i]=x[n-1];}
      // else{y[i-(m1-m)]=ytrimmed[i];}
      //}
      //alpha=y[0];
      for(i=0;i<m;i++)
//caculate matrix D and V,if x[j]>=y[i], D[i][j]=0,V[i][j]=0,
//if x[j]<y[i],D[i][j]=y[j]-x[i],V[i][j]++
      {
         for(j=0;j<n+1;j++)
         {
            D[i*(n+1)+j]=D1[i*(n+1)+j]=REAL(D_Matrix)[(i+m1-m)*(n+1)+j]-REAL(D_Matrix)[(i+m1-m)*(n+1)];
            V[i*(n+1)+j]=REAL(V_Matrix)[(i+m1-m)*(n+1)+j]-REAL(V_Matrix)[(i+m1-m)*(n+1)];
            if(j<1)Z[i*(n+1)]=0;
            else   Z[i*(n+1)+j]=1;
         }
         c-=REAL(D_Matrix)[(i+m1-m)*(n+1)];
      }
      D_star=(double*)malloc((n+1)*m*sizeof(double));
      V_star=(int*)malloc((n+1)*m*sizeof(int));
      v_bar=(int*)malloc(m*sizeof(int));
      index=(int*)malloc(m*sizeof(int));
      sol=(int*)malloc(m*sizeof(int));
      bsort(D1,m*(n+1));
      start=0;
      while(D1[start]>REAL(Constraint)[0])start++;
      Rank_max[0]=0;
      start--;
      do{
           start++;

            for(i=0;i<m;i++)
            {
               j1=0;
               for(j=0;j<n+1;j++){
                   if(D[i*(n+1)+j]-D1[start]<eps){
                      D_star[i*(n+1)+j]=Z[i*(n+1)+j]*(D1[start]-D1[start]);
                      //D_star[i*(n+1)+j]=Z[i*(n+1)+j]*D1[start];
                      j1=j;
                   }
                   else{
                         D_star[i*(n+1)+j]=Z[i*(n+1)+j]*(D[i*(n+1)+j]-D1[start]);
                         //D_star[i*(n+1)+j]=Z[i*(n+1)+j]*D[i*(n+1)+j];
                   }
               }
               //if(i==0)j1=n;
               v_bar[i]=V[i*(n+1)+j1];
               index[i]=j1;
               for(j=0;j<n+1;j++){
                  V_star[i*(n+1)+j]=intmax(V[i*(n+1)+j]-v_bar[i],0);
                  Delta[i*(n+1)+j]=0;
               }
            }
            CP(D_star,c-c1*D1[start],Z,c1,V_star,m,n+1,Delta,sol);
            //CP(D_star,c,Z,c1,V_star,m,n+1,Delta,sol);
            if(exact!=0) EMKP(D_star,c-c1*D1[start],Z,c1,V_star,m,n+1,Delta,sol,MaxIter);
               //EMKP(D_star,c,Z,c1,V_star,m,n+1,Delta,sol,MaxIter);
            else MRLS(D_star,c-c1*D1[start],Z,c1,V_star,m,n+1,Delta,sol,MaxIter);
               //MRLS(D_star,c,Z,c1,V_star,m,n+1,Delta,sol,MaxIter);
            Rank[0]=0;
            for(i=0;i<m;i++){
               Rank[0]+=Z[i*(n+1)+sol[i]];
            }
            if(Rank[0]>c1-1){
              for(i=0;i<m;i++){
                 if(sol[i]<=index[i])
                 {
                       Delta[i*(n+1)+sol[i]]=0;
                       sol[i]=index[i];
                       Delta[i*(n+1)+index[i]]=1;
                 }
              }
            }else{
               for(i=0;i<m;i++){
                  if(sol[i]>0&&sol[i]<=index[i]){
                       Delta[i*(n+1)+sol[i]]=0;
                       sol[i]=index[i];
                       Delta[i*(n+1)+index[i]]=1;
                  }
               }
            }
            Rank[0]=0;
            for(i=0;i<m;i++){
               /*exist=0;
               temp=0;
               for(j=0;j<n+1;j++)
               {
                   temp+=Delta[i*(n+1)+j]*Z[i*(n+1)+j];
               }
               if(temp>.5){
                  j=1;
                  while(j<n+1 &&D[i*(n+1)+1]-D1[start]<eps){
                       if(Delta[i*(n+1)+j]>0){Delta[i*(n+1)+j]=0;exist=1;}
                       j++;
                  }
                  j--;
                  if(exist>0)Delta[i*(n+1)+j]=1;
               }*/
               for(j=0;j<n+1;j++)Rank[0]+=Delta[i*(n+1)+j]*V[i*(n+1)+j];
            }
            if(Rank[0]>Rank_max[0]){
               Rank_max[0]=Rank[0];
               for(i=0;i<m;i++)
                  for(j=0;j<n+1;j++)Delta_max[i*(n+1)+j]=Delta[i*(n+1)+j];
            }
       }while(D1[start]>0&&start<m*(n+1));
      //}while(D1[start]>0&&start<0);
       for(i=0;i<m;i++)
       {
         temp=0;
         for(j=0;j<n+1;j++)
         {
            temp+=Delta_max[i*(n+1)+j]*D[i*(n+1)+j];
            INTEGER(solution)[(i+m1-m)*(n+1)+j]=Delta_max[i*(n+1)+j];
         }
         //ytrimmed[i+m1-m]=y[i]-temp;
       }
       //bsort(ytrimmed,m1);
       for(i=0;i<m1-m;i++)
       {
         for(j=0;j<n;j++)
            INTEGER(solution)[i*(n+1)+j]=0;
         INTEGER(solution)[i*(n+1)+n]=1;
       }
      //else{
      //   for(i=0;i<m1;i++){
      //      for(j=0;j<n+1;j++){INTEGER(solution)[i*(n+1)+j]=0;}
      //      if(i<m1-m)INTEGER(solution)[i*(n+1)+n]=1;
      //      else{INTEGER(solution)[i*(n+1)]=1;}
      //   }
      //}
      //for(i=0;i<m1;i++){
      //   REAL(treat)[i]=ytrimmed[i];
      //}
      free(sol);
      free(v_bar);
      free(V_star);
      free(D_star);
      //free(x);
      //free(y);
      //free(ytrimmed);
      free(D);
      free(D1);
      //free(U);
      free(Z);
      free(Delta);
      free(Delta_max);
      free(Rank);
      free(Rank_max);
      free(V);
      free(index);
      //SET_VECTOR_ELT(lists,0,treat);
 	  //SET_STRING_ELT(names,0,mkChar("Modified"));
      SET_VECTOR_ELT(lists,0,solution);
 	  SET_STRING_ELT(names,0,mkChar("Solution"));
	  setAttrib(lists,R_NamesSymbol,names);
      PutRNGstate();
      UNPROTECT(3);
      return(lists);
}

