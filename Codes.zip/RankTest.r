library(coin)
########################################################################
#######                    MCKP Algorithm                     ##########
########################################################################
dyn.load("MCKP")

##############Tranformation function of the ranks
f=function(x,a=2)
{
   #x  ############Wilcoxon test
   x^(a-1) ###########Conover Salsburg test
}
#############MCKP procedure that gives##################################
#############the maximum movements of the treatment group###############
mckp.max=function(control.group,treatment.group,constraint,alpha,f)
{
   control=sort(control.group,decreasing=TRUE)
   treatment=sort(treatment.group,decreasing=TRUE)
   n=length(treatment)
   m=length(control)
   D=matrix(0,n,m+1)
   for(i in 1:n)
     for(j in 2:(m+1))
       D[i,j]=max(0,treatment[i]-control[j-1])
   V=matrix(0,n,m+1)
   for(i in 1:n)
     for(j in 1:(m+1))
       V[i,j]=ifelse(D[i,j]>0,V[i,j-1]+1,0)
   ranks=rank(c(treatment,control)) 
   V1=f(matrix(ranks[1:n],n,m+1))
   V2=f(matrix(ranks[1:n],n,m+1)-V)
   V=V1-V2
   tmp=.Call("MCKP",as.double(t(D)),as.integer(n),
    as.double(t(V)),as.integer(m),as.double(constraint),
    as.double(alpha),new.env())
   solution=t(matrix(tmp$Solution,m+1,n))
   treat.modified=sort(treatment-as.vector(apply(solution*D,1,sum)),decreasing=TRUE)
   list(Modified=treat.modified,Solution=solution)
}

#############MCKP procedure that gives##################################
#############the minimum movements of the treatment group###############
mckp.min=function(control.group,treatment.group,C,alpha,f)
{
   control=sort(control.group,decreasing=TRUE)
   treatment=sort(treatment.group,decreasing=TRUE)
   n=length(treatment)
   m=length(control) 
   D=matrix(0,n,m+1)
   for(i in 1:n)
     for(j in 2:(m+1))
       D[i,j]=max(0,treatment[i]-control[j-1])
   V=matrix(0,n,m+1)
   for(i in 1:n)
     for(j in 1:(m+1))
       V[i,j]=ifelse(D[i,j]>0,V[i,j-1]+1,0)
   ranks=rank(c(treatment,control)) 
   V1=f(matrix(ranks[1:n],n,m+1))
   V2=f(matrix(ranks[1:n],n,m+1)-V)
   V=V1-V2
   K=max(C,max(as.vector(D)))
   D=cbind(D[,-1],K)
   V.max=apply(V,1,max)
   D1=K-D
   V1=V.max%*%t(rep(1,m+1))-V
   ind1=seq(n,1,by=-1)
   ind2=seq(m+1,1,by=-1)
   D1=D1[ind1,ind2]
   V1=V1[ind1,ind2]
   C1=K-C
   if(C1==K){solution=matrix(0,n,m+1)}else{
    tmp=.Call("MCKP",as.double(t(D1)),as.integer(n),
    as.double(t(V1)),as.integer(m),as.double(C1),
    as.double(alpha),new.env())
    solution=t(matrix(tmp$Solution,m+1,n))
    solution=solution[ind1,ind2]
   }
   treat.modified=sort(treatment-as.vector(apply(solution*D,1,sum)),decreasing=TRUE)
   list(Modified=treat.modified,Solution=solution)
}


########################################################################
#######                    MMKP Algorithm                     ##########
########################################################################
dyn.load("MMKP")
#############MMKP procedure that gives##################################
#############the maximum movements of the treatment group###############
mmkp.max=function(control.group,treatment.group,C,alpha,MaxIter=100,Exact=TRUE,f)
{
   control=sort(control.group,decreasing=TRUE)
   treatment=sort(treatment.group,decreasing=TRUE)
   n=length(treatment)
   m=length(control) 
   D=matrix(0,n,m+1)
   for(i in 1:n)
     for(j in 2:(m+1))
       D[i,j]=max(0,treatment[i]-control[j-1])
   V=matrix(0,n,m+1)
   for(i in 1:n)
     for(j in 1:(m+1))
       V[i,j]=ifelse(D[i,j]>0,V[i,j-1]+1,0)
   ranks=rank(c(treatment,control)) 
   V1=f(matrix(ranks[1:n],n,m+1))
   V2=f(matrix(ranks[1:n],n,m+1)-V)
   V=V1-V2
   trim.num=as.integer(n*alpha/2)
   if(trim.num+1>n-trim.num)stop("alpha is too large!")
   tmp=sum(D[(trim.num+1):(n-trim.num),1])
   if(tmp>C*(n-2*trim.num)){stop("The constraint is too small!")}else
   if (tmp==C*(n-2*trim.num))
   {
       solution=matrix(0,n,m+1)
       if(trim.num>=1)solution[1:(trim.num),m+1]=1
       solution[(trim.num+1):n,1]=1
   }else{
       D.tmp=sort(D)
       D.tmp=D.tmp[D.tmp>0]
       if(D.tmp[1]>=C*(n-2*trim.num)){
          solution=matrix(0,n,m+1)
          if(trim.num>=1)solution[1:(trim.num),m+1]=1
          solution[(trim.num+1):n,1]=1
       }else{
          tmp=.Call("MMKP",as.double(t(D)),as.integer(n),
           as.double(t(V)),as.integer(m),as.double(C),
           as.double(alpha/2),as.integer(MaxIter),as.integer(Exact),new.env())
          solution=t(matrix(tmp$Solution,m+1,n))
       }
   }
   treat.modified=sort(treatment-as.vector(apply(solution*D,1,sum)),decreasing=TRUE)
   list(Modified=treat.modified,Solution=solution)
}

#############MMKP procedure that gives##################################
#############the minimum movements of the treatment group###############
mmkp.min=function(control.group,treatment.group,C,bound=NULL,alpha,MaxIter=100,Exact=TRUE,f)
{
   control=sort(control.group,decreasing=TRUE)
   treatment=sort(treatment.group,decreasing=TRUE)
   n=length(treatment)
   m=length(control) 
   D=matrix(0,n,m+1)
   for(i in 1:n)
     for(j in 2:(m+1))
       D[i,j]=max(0,treatment[i]-control[j-1])
   V=matrix(0,n,m+1)
   for(i in 1:n)
     for(j in 1:(m+1))
       V[i,j]=ifelse(D[i,j]>0,V[i,j-1]+1,0)
   ranks=rank(c(treatment,control)) 
   V1=f(matrix(ranks[1:n],n,m+1))
   V2=f(matrix(ranks[1:n],n,m+1)-V)
   V=as.matrix(V1-V2)
   K=max(C,max(as.vector(D)))
   if(!is.null(bound)){K=min(K,bound)}
   D=cbind(D[,-1],K)
   V.max=apply(V,1,max)
   D1=K-D
   V1=V.max%*%t(rep(1,m+1))-V
   ind1=seq(n,1,by=-1)
   ind2=seq(m+1,1,by=-1)
   D1=D1[ind1,ind2]
   V1=V1[ind1,ind2]
   C1=K-C
   trim.num=as.integer(n*alpha/2)
   if(trim.num+1>n-trim.num)stop("alpha is too large!")
   tmp=sum(D1[(trim.num+1):(n-trim.num),1])
   if(tmp>C1*(n-2*trim.num)){stop("The constraint is too large!")}else
   if(C1==K){solution=matrix(0,n,m+1)}else
   if (tmp==C1*(n-2*trim.num))
   {
       solution=matrix(0,n,m+1)
       if(trim.num>=1)solution[1:(trim.num),m+1]=1
       solution[(trim.num+1):n,1]=1
   }else{
       D.tmp=sort(D1)
       D.tmp=D.tmp[D.tmp>0]
       if(D.tmp[1]>=C1*(n-2*trim.num)){
          solution=matrix(0,n,m+1)
          if(trim.num>=1)solution[1:(trim.num),m+1]=1
          solution[(trim.num+1):n,1]=1
       }else{
          tmp=.Call("MMKP",as.double(t(D1)),as.integer(n),
           as.double(t(V1)),as.integer(m),as.double(C1),
           as.double(alpha/2),as.integer(MaxIter),as.integer(Exact),new.env())
          solution=t(matrix(tmp$Solution,m+1,n))
       }
   }
   solution=solution[ind1,ind2]
   treat.modified=sort(treatment-as.vector(apply(solution*D,1,sum)),decreasing=TRUE)
   list(Modified=treat.modified,Solution=solution)
}

########################################################################
######################            Data          ########################
########################################################################
#### Control Group  ###########
##Study 1
#control=c(22.8,10.2,20.8,27,19.2,9,14.2,19.8,14.5,14.8)
#control=31-c(23.5,31,19.5,26.2,26.5,25.2,24.5,23.8,27.8,22)
##Study 2
#control=c(3.2,5.1,8.3,8.8,9.5,11.9,14.0)
##Study 3
#control=c(5,5.4,6.1,10.9,11.8,12,12.3,14.8,15,16.8,17.2,17.2,17.4,17.5,18.5,
#      18.7,18.7,19.2,19.5,20.7,21.2,22.1,24)
##Study 4
#control=c(34,23,36,25,35,23,87,48)
##Study 5
control=12.45-c(2.20,2.69,3.54,3.75,3.83,4.08,4.27,4.53,5.32,6.18,6.22,6.33,6.970,6.971,7.52,8.36,11.65,12.45)

#### Treatment Group ##########
##Study 1
#treatment=c(23.5,31,19.5,26.2,26.5,25.2,24.5,23.8,27.8,22)
#treatment=31-c(22.8,10.2,20.8,27,19.2,9,14.2,19.8,14.5,14.8)
##Study 2
#treatment=c(3.7,6.8,8.4,8.5,10.0,11.3,12.0,12.5,18.7,19,20,22.7,
# 24,31.8,33.3,36)
##Study 3
#treatment=c(12,12,12.9,13.6,16.6,17.2,17.5,18.2,19.1,19.3,19.8,20.3,20.5,20.6,
#        21.3,21.6,22.1,22.2,22.6,23.1,24,24.3,26.7,29.7);
##Study 4
#treatment=c(41,86,90,74,146,57,62,78,55,105,46,94,26,101,72,119,88)
##Study 5
treatment=12.45-c(.71,1.66,2.01,2.16,2.420,2.421,2.56,2.60,3.31,3.64,3.740,3.741,4.39,4.50,5.07,5.26,8.15,8.24)


########################################################################
############          Hypothesis Testing              ##################
########################################################################
#### Null Hypothesis: Trimmed Mean=C  #########
C1=0  #######Trimmed mean>C1

C2=6.23 ########Trimmed mean<C2

#### Trimmed fraction ##########
alpha=0.6
#alpha=0.2
#UpperTrimmed=TRUE       ### Upper Trimmed Mean ###
UpperTrimmed=FALSE       ## Regular Trimmed Mean ##
Exact=T

####### WilCox Rank Test #######
epsilon=1e-6
if(UpperTrimmed){
   modifiedTreat.max=mckp.max(control,treatment,C1,alpha,f=f)
   modifiedTreat.min=mckp.min(control,treatment,C2,alpha,f=f)
}else{
   modifiedTreat.max=mmkp.max(control,treatment,C1,alpha,MaxIter=100,Exact=Exact,f=f)
   modifiedTreat.min=mmkp.min(control,treatment,C2,bound=NULL,alpha,MaxIter=100,Exact=Exact,f=f)
}
modifiedTreat.max
modifiedTreat.min
control=sort(control,decreasing=TRUE)
treatment=sort(treatment,decreasing=TRUE)
n=length(treatment)
m=length(control) 
D=matrix(0,n,m+1)
for(i in 1:n)
   for(j in 2:(m+1))
      D[i,j]=max(0,treatment[i]-control[j-1])
V=matrix(0,n,m+1)
for(i in 1:n)
   for(j in 1:(m+1))
       V[i,j]=ifelse(D[i,j]>0,V[i,j-1]+1,0)

sum(modifiedTreat.max$Solution*V)
modifiedTreat.max$Solution*D                                   
cap.max=sort(D[matrix(as.logical(modifiedTreat.max$Solution),n,m+1)])
mean(cap.max,trim=as.integer(alpha/2*length(cap.max))/length(cap.max)) #######Real capacity used by the first hypthesis testing

K=max(C2,max(D))
D=cbind(D[,-1],K)
sum(modifiedTreat.min$Solution*V)
modifiedTreat.min$Solution*D
cap.min=sort(D[matrix(as.logical(modifiedTreat.min$Solution),n,m+1)])
mean(cap.min,trim=as.integer(alpha/2*length(cap.min))/length(cap.min)) #######Real capacity used by the second hypthesis testing

#observations.max=31-c(modifiedTreat.max$Modified,sort(control,decreasing=TRUE))+epsilon*seq(1:(n+m))
observations.max=c(modifiedTreat.max$Modified,sort(control,decreasing=TRUE))+epsilon*seq(1:(n+m))
rank.max=f(rank(observations.max))
group=factor(c(rep(1,n),rep(2,m)))
if(n+m>=36){
  distribution='approximate'
}else{
  distribution='exact'
}



#distribution='approximate'
######The first one-sided hypothesis test 
#test.max=1-pvalue(oneway_test(rank.max~group,alternative='less',distribution=distribution))
#test.max=1-wilcox.test(x=observations.max[1:n],y=observations.max[(n+1):(n+m)],alternative="less")$p.value
test.max=oneway_test(rank.max~group,alternative='greater',distribution=distribution)
test.max

######The second one-sided hypothesis test
#observations.min=31-c(modifiedTreat.min$Modified,sort(control,decreasing=TRUE))-epsilon*seq(1:(n+m))
observations.min=c(modifiedTreat.min$Modified,sort(control,decreasing=TRUE))-epsilon*seq(1:(n+m))
rank.min=f(rank(observations.min))
#test.min=1-pvalue(oneway_test(rank.min~group,alternative='greater',distribution=distribution))
#test.min=1-wilcox.test(x=observations.min[1:n],y=observations.min[(n+1):(n+m)],alternative="greater")$p.value
test.min=oneway_test(rank.min~group,alternative='less',distribution=distribution)
test.min

#conover.salsburg.test(observations.min[1:n],observations.max[(n+1):(n+m)],5,"less")

dyn.unload("MCKP")
dyn.unload("MMKP")
